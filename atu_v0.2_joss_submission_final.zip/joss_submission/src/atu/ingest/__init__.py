"""Source trace ingest adapters."""
